package com.csc340.AlternativeProduct;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Robby Martin
 */
@Service
public class AlternativeProductService {
    
    @Autowired
    AlternativeProductRepository repo;

    /**
     * Get all alternative products
     * @return the list of users.
     */
    public List<AlternativeProduct> getAllAlternativeProducts() {
        return repo.findAll();
    }


}
