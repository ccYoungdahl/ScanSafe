package com.csc340.AlternativeProduct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Robby Martin
 */
@Controller
@RequestMapping("/influencer")
public class AlternativeProductController {
    
    // I feel like this is where things aren't working. I also feel like I missed an entire semester where I should have learned all this? lol
    @Autowired
    private AlternativeProductService service;

    @GetMapping("/influencerDashboard")
    public String getAllAlternativeProducts(Model model) {
        model.addAttribute("alternativeProductList", service.getAllAlternativeProducts());
        return "influencer/influencerDashboard";
    }

}
