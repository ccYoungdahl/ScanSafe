package com.csc340.ScanSafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScanSafeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScanSafeApplication.class, args);
    }
}
