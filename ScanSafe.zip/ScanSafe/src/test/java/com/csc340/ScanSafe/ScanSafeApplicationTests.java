package com.csc340.ScanSafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScanSafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
